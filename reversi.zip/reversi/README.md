Reversi
=======

A PHP/Javascript implementation of the Reversi board game.